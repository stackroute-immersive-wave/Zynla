'use strict';
const logger = require('./../../applogger');
let driver = require('../config/neo4j');
let session = driver.session();
//
// const User = require('./bookEntity');


console.log("inside me")
let bookController = {
saveToc: function(req, res) {
        console.log("inside bookController")
        // res.send("success entry")
        let chapterData = JSON.parse(req.body.book);

        chapterData.forEach((chapter,chapterIndex,chapterArr)=>{

           if(!chapter.hasOwnProperty('name')){
             chapterArr[chapterIndex]["Chapter#"+chapterIndex]
             .forEach((topic,topicIndex,topicArr)=>{
               if(!topic.hasOwnProperty('name')){
                 topicArr[topicIndex]["Topic#"+topicIndex].forEach((subTopic,subTopicIndex,subTopicArr)=>{
                    if(!subTopic.hasOwnProperty('name')){
                   let newSubTopicArr = []
                   let nameObj = {};
                   nameObj["name"] = subTopicArr[subTopicIndex]["Subtopic#"+subTopicIndex]
                   newSubTopicArr.push(nameObj)
                   let query = '\
                   match (n:concept{name:"'+nameObj["name"]+'"})-[r]-(:question)-[answer_of]-(m)\
                    where (m:text) or (m:blog)or (m:video)\
                     with  {intent:type(r),value:collect({label:labels(m)[0],value:m.value})}\
                      as value return collect(value) as answer \
                      ';
                      session.run(query).then(function(result) {
                          /*eslint-disable*/
                          session.close()
                          newSubTopicArr.push.apply(newSubTopicArr,result.records[0]._fields[0])
                          subTopicArr[subTopicIndex]["Subtopic#"+subTopicIndex]=newSubTopicArr
                          console.log(chapterData[chapterIndex]["Chapter#"+chapterIndex][topicIndex]["Topic#"+topicIndex],"result");
                          console.log(newSubTopicArr,"newSubTopicArr");
                          console.log(chapterIndex,topicIndex,subTopicIndex,chapterData.length,chapterArr.length,topicArr.length)
                          if(chapterArr.length==(chapterIndex+1)&&topicArr.length==(topicIndex+1)&&subTopicArr.length==(subTopicIndex+1))
                          {console.log(nameObj["name"],"nameObj")
                            res.send(chapterData)}
                      })
                 }
                 })
               }
             })
           }
         })
    }
}

module.exports=bookController;
