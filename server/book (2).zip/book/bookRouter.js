'use strict';
const router = require('express').Router();
const passport = require('passport');

let bookController = require('./bookController.js');

//#swathi Add the ToC to the database
router.post('/saveToc', bookController.saveToc);

module.exports = router;
