let mongoose = require('mongoose');
mongoose.Promise = global.Promise;
let schema = new mongoose.Schema({
	domain:String,
    title:String,
    chapter:String,
    topic:String
});